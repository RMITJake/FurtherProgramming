package fpoua.week2;

public interface CanSwim {
	public void swim();
}
