package fpoua.week6.assessment;

public interface CanSwim {
	public void swim();
}
