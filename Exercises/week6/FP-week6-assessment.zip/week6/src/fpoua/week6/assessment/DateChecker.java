package fpoua.week6.assessment;

import java.text.*;
import java.util.Date;
import java.util.Calendar;

public class DateChecker {
	
	public static Date convertStringToDate(String dt1String) throws ParseException {
		SimpleDateFormat sdformat = new SimpleDateFormat("dd/MM/yyyy K:mma");
		Date dt1 = sdformat.parse(dt1String);
		return dt1;
	}

	public static void compareTwoDateTimes(Date dt1, Date dt2)  throws ParseException{
		// TODO Auto-generated constructor stub
		SimpleDateFormat sdformat = new SimpleDateFormat("dd/MM/yyyy K:mma");

		System.out.println("The date 1 is: " + sdformat.format(dt1));
		System.out.println("The date 2 is: " + sdformat.format(dt2));
		if (dt1.compareTo(dt2) > 0) {
			System.out.println("Datetime 1 occurs after Date 2");
		} else if (dt1.compareTo(dt2) < 0) {
			System.out.println("Datetime 1 occurs before Date 2");
		} else if (dt1.compareTo(dt2) == 0) {
			System.out.println("Both dates are equal");
		}
	}
	
	public static Date addHourToDate(Date dt1, int hourToAdd)  throws ParseException{
		// TODO Auto-generated constructor stub

		Calendar cal = Calendar.getInstance();
		cal.setTime(dt1);  
		cal.add(Calendar.HOUR_OF_DAY, hourToAdd); 
		Date d1PlusHour = cal.getTime(); 
		
		return d1PlusHour;

	}
	
	public static boolean isInputDateWithinRange(Date startDate, Date endDate, Date inputDate) throws ParseException {

		if(inputDate.compareTo(startDate)>=0 && inputDate.compareTo(endDate) <= 0)
			return true;
		return false;
	}

	public static void main(String[] args) {
		try {
			SimpleDateFormat sdformat = new SimpleDateFormat("dd/MM/yyyy K:mma");
			Date startDate = sdformat.parse("20/12/2024 8:00pm");
			Date inputDate = sdformat.parse("20/12/2024 9:00pm");
			
			compareTwoDateTimes(startDate, inputDate);
			
			int duration = 1;
			Date endDate = addHourToDate(startDate, duration);
			
			System.out.println("The endDate is startDate time plus " + duration + " which is " + sdformat.format(endDate));
			boolean isWithinInput = isInputDateWithinRange(startDate, endDate, inputDate);
			
			System.out.println(isWithinInput);
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}



}
