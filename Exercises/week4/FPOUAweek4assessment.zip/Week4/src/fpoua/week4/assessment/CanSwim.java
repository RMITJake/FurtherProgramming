package fpoua.week4.assessment;

public interface CanSwim {
	public void swim();
}
