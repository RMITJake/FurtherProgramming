package fpoua.week4.assessment;

public class Panda extends Animal {

	public Panda(String name, String colour, int age) {
		super(name, colour, age);
	}

	public Panda(int id, String name, String colour, int age) {
		//ASSESSMENT WEEK 4:
		//Complete the initialisation of fields for this constructor
	}

	@Override
	public void makeSound() {
		// Do nothing
	}

}
