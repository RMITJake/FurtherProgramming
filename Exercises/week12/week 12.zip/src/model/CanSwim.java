package src.model;

public interface CanSwim {
	public void swim();
}
